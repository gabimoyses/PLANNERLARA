'use strict';

const DIAS = ['Domingo', 'Segunda-feira', 'Terça-feira', 'Quarta-feira', 'Quinta-feira', 'Sexta-feira', 'Sábado'];
const ORDEM = [1, 2, 3, 4, 5, 6, 0]; // semana começando na segunda
const CORES = ['rosa', 'lilas', 'menta', 'laranja', 'amarelo', 'azul', 'rosa'];
const KEY = 'organizador:v1';

/* ---------- utilitários ---------- */
const pad = n => String(n).padStart(2, '0');
const iso = d => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
const parse = s => { const [y, m, d] = s.split('-').map(Number); return new Date(y, m - 1, d); };
const hojeISO = () => iso(new Date());
const uid = () => Date.now().toString(36) + Math.random().toString(36).slice(2, 6);
const esc = s => String(s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const fmt = d => d.toLocaleDateString('pt-BR', { day: 'numeric', month: 'short' }).replace('.', '');
const diasAte = s => Math.round((parse(s) - parse(hojeISO())) / 864e5);
const byDate = (a, b) => a.date.localeCompare(b.date);
const linhas = t => (t || '').split('\n').map(s => s.trim()).filter(Boolean);
const pct = (d, t) => (t ? Math.round((d / t) * 100) : 0);
const fmtKg = n => String(Math.round(n * 100) / 100).replace('.', ',');
const lerKg = v => {
  if (v == null || String(v).trim() === '') return null;
  const n = Number(String(v).replace(',', '.'));
  return isFinite(n) && n >= 0 ? n : null;
};

const lerNota = v => { const n = lerKg(v); return n == null ? null : Math.min(10, n); };

function mondayOf(d) {
  const r = new Date(d.getFullYear(), d.getMonth(), d.getDate());
  r.setDate(r.getDate() - ((r.getDay() + 6) % 7));
  return r;
}

function contagem(s) {
  const n = diasAte(s);
  if (n === 0) return 'hoje';
  if (n === 1) return 'amanhã';
  if (n > 1) return `em ${n} dias`;
  return n === -1 ? 'ontem' : `há ${-n} dias`;
}

/* ---------- dados (salvos automaticamente no aparelho) ---------- */
const vazio = () => ({ items: [], exams: [], workouts: {}, sessions: {}, exNomes: {}, inicio: hojeISO(), materias: [], avals: [], metas: [] });

// Plano de treino por dia da semana: { nome, exs: [{ id, nome, series }] }
// Aceita formatos antigos (texto solto).
function normTreinos(w) {
  const out = {};
  Object.keys(w || {}).forEach(k => {
    let v = w[k];
    if (typeof v === 'string') v = { nome: '', texto: v };
    if (!v) return;
    const exs = Array.isArray(v.exs)
      ? v.exs.filter(x => x && x.nome).map(x => ({ id: x.id || uid(), nome: String(x.nome), series: x.series || '' }))
      : linhas(v.texto).map(t => ({ id: uid(), nome: t, series: '' }));
    if (v.nome || exs.length) out[k] = { nome: v.nome || '', exs };
  });
  return out;
}

function carregar(d) {
  const r = { ...vazio(), ...d };
  r.workouts = normTreinos(r.workouts);
  r.sessions = r.sessions || {};
  Object.keys(r.sessions).forEach(k => {
    const s = r.sessions[k] || {};
    r.sessions[k] = { done: Array.isArray(s.done) ? s.done : [], cargas: s.cargas || {}, total: Number(s.total) || 0 };
  });
  r.exNomes = r.exNomes || {};
  Object.keys(r.workouts).forEach(n => r.workouts[n].exs.forEach(x => { r.exNomes[x.id] = x.nome; }));
  r.materias = (Array.isArray(r.materias) ? r.materias : [])
    .filter(m => m && m.nome)
    .map(m => ({ id: m.id || uid(), nome: String(m.nome), t1: lerNota(m.t1), t2: lerNota(m.t2), t3: lerNota(m.t3) }));
  r.avals = (Array.isArray(r.avals) ? r.avals : [])
    .filter(a => a && a.date)
    .map(a => ({ id: a.id || uid(), materiaId: a.materiaId, tipo: a.tipo === 'Trabalho' ? 'Trabalho' : 'Prova', date: a.date, conteudo: a.conteudo || '' }));
  r.metas = Array.isArray(r.metas) ? r.metas : [];
  delete r.mediaMin;
  if (Array.isArray(r.exams) && r.exams.length) { // provas da versão antiga viram avaliações
    r.exams.forEach(e => {
      let m = r.materias.find(x => x.nome.toLowerCase() === String(e.subject).toLowerCase());
      if (!m) { m = { id: uid(), nome: String(e.subject), t1: null, t2: null, t3: null }; r.materias.push(m); }
      r.avals.push({ id: e.id || uid(), materiaId: m.id, tipo: 'Prova', date: e.date, conteudo: e.topics || '' });
    });
  }
  r.exams = [];
  return r;
}

function load() {
  try {
    const d = JSON.parse(localStorage.getItem(KEY));
    if (d) return carregar(d);
  } catch (e) { /* começa vazio */ }
  return vazio();
}

let db = load();

function save() {
  try { localStorage.setItem(KEY, JSON.stringify(db)); }
  catch (e) { alert('Não foi possível salvar neste navegador. Libere espaço ou instale o app na tela inicial.'); }
}
save(); // grava já a versão normalizada (ids estáveis)

// Pede ao navegador para não apagar os dados sozinho
let persistido = false;
async function protegerDados() {
  try {
    if (navigator.storage && navigator.storage.persist) {
      persistido = (await navigator.storage.persisted()) || (await navigator.storage.persist());
    }
  } catch (e) { /* ignora */ }
  if (view === 'hoje') render();
}

/* ---------- estado da tela ---------- */
let view = 'hoje';
let weekStart = mondayOf(new Date());
let treinoSeg = 'progresso';
let selDate = hojeISO();
let calMonth = { y: new Date().getFullYear(), m: new Date().getMonth() };
let editingDay = null;
let draft = null;
let pendingFocus = null;
let escolaSeg = 'boletim';
let selAgenda = hojeISO();
let agMonth = { y: new Date().getFullYear(), m: new Date().getMonth() };
let metaDraft = { tipo: 'semana', alvo: '', ex: '', prazo: '' };

/* ---------- treino: cálculos ---------- */
const planoDe = date => db.workouts[parse(date).getDay()];
const planTotal = date => { const p = planoDe(date); return p ? p.exs.length : 0; };

function getSessao(date) {
  if (!db.sessions[date]) db.sessions[date] = { done: [], cargas: {}, total: 0 };
  return db.sessions[date];
}

// Progresso de um dia: hoje/futuro usa o plano atual; passado usa o que foi registrado
function statDia(date) {
  if (date < db.inicio) return { done: 0, total: 0 };
  const s = db.sessions[date];
  if (date >= hojeISO() || !s) {
    const p = planoDe(date);
    const ids = p ? p.exs.map(x => x.id) : [];
    return { done: s ? ids.filter(i => s.done.includes(i)).length : 0, total: ids.length };
  }
  return { done: Math.min(s.done.length, s.total), total: s.total };
}

function statSemana(date) {
  const m = mondayOf(parse(date));
  let done = 0, total = 0, dias = 0, completos = 0;
  for (let k = 0; k < 7; k++) {
    const st = statDia(iso(new Date(m.getFullYear(), m.getMonth(), m.getDate() + k)));
    done += st.done; total += st.total;
    if (st.total) { dias++; if (st.done >= st.total) completos++; }
  }
  return { done, total, dias, completos };
}

// Última carga registrada (exercício concluído) antes de uma data
function ultimaCarga(id, date) {
  const datas = Object.keys(db.sessions).filter(d => d < date).sort().reverse();
  for (const d of datas) {
    const s = db.sessions[d];
    if (s.done.includes(id) && s.cargas[id] != null) return s.cargas[id];
  }
  return null;
}

/* ---------- peças de HTML ---------- */
const bloco = (cor, titulo, corpo, depois = '') =>
  `<section class="bloco ${cor}"><h2><span>${titulo}</span>${depois}</h2>${corpo}</section>`;

const itemsOf = date =>
  db.items.filter(i => i.date === date)
    .sort((a, b) => (a.time || '24:00').localeCompare(b.time || '24:00'));

const li = i => `
  <li class="item${i.done ? ' done' : ''}">
    <input type="checkbox" data-act="toggle" data-id="${i.id}"${i.done ? ' checked' : ''} aria-label="Concluir">
    <span class="hora">${i.time || ''}</span>
    <span class="txt">${esc(i.title)}</span>
    <button type="button" class="x" data-act="del-item" data-id="${i.id}" aria-label="Apagar ${esc(i.title)}">×</button>
  </li>`;

const lista = items => items.length
  ? `<ul>${items.map(li).join('')}</ul>`
  : '<p class="vazio">Nada marcado.</p>';

const formItem = date => `
  <form class="add" data-form="item" data-date="${date}">
    <input name="title" placeholder="Novo compromisso ou tarefa" aria-label="Compromisso ou tarefa" required>
    <input name="time" type="time" aria-label="Horário (opcional)">
    <button class="primary">Adicionar</button>
  </form>`;

const matNome = id => { const m = db.materias.find(x => x.id === id); return m ? m.nome : '(matéria apagada)'; };

const avalRow = a => `
  <li class="item prova">
    <div class="txt">
      <strong>${esc(matNome(a.materiaId))}</strong><br>
      <small>${esc(a.tipo)}${a.conteudo ? ' – ' + esc(a.conteudo) : ''}</small>
    </div>
    <span class="cd">${contagem(a.date)}</span>
  </li>`;

function barraP(rotulo, direita, p) {
  return `<div class="barra">
    <div class="bar-top"><span>${rotulo}</span><b>${direita} · ${p}%</b></div>
    <div class="trilho"><div class="fill" style="width:${p}%"></div></div>
  </div>`;
}

function barra(rotulo, done, total) {
  if (!total) return `<div class="barra"><div class="bar-top"><span>${rotulo}</span></div><p class="vazio">Sem treino planejado.</p></div>`;
  return barraP(rotulo, `${done}/${total}`, pct(done, total));
}

function barraSemana(date) {
  const s = statSemana(date);
  return barra('Exercícios da semana', s.done, s.total) +
    (s.dias ? `<p class="vazio">Treinos completos: ${s.completos} de ${s.dias}</p>` : '');
}

// Treino só para leitura (Semana, Amanhã, Plano)
function treinoBox(n) {
  const w = db.workouts[n];
  if (!w) return '<div class="treino-box descanso">💪 Treino: descanso</div>';
  return `<div class="treino-box">
    <div class="th">💪 <strong>${esc(w.nome || 'Treino')}</strong></div>
    ${w.exs.length ? `<ul class="ex">${w.exs.map(x => `<li>${esc(x.nome)}${x.series ? ` <small>${esc(x.series)}</small>` : ''}</li>`).join('')}</ul>` : ''}
  </div>`;
}

// Treino do dia com check e carga de cada exercício
function sessao(date) {
  const p = planoDe(date);
  if (!p) return '<div class="treino-box descanso">💪 Sem treino neste dia</div>';
  if (!p.exs.length) return '<div class="treino-box descanso">Este treino ainda não tem exercícios. Adicione na aba Treino, em Plano.</div>';
  const s = db.sessions[date] || { done: [], cargas: {} };
  const st = statDia(date);
  const rows = p.exs.map(x => {
    const ok = s.done.includes(x.id);
    const kg = s.cargas[x.id] != null ? s.cargas[x.id] : ultimaCarga(x.id, date);
    return `
    <li class="item${ok ? ' done' : ''}">
      <input type="checkbox" data-act="ex-toggle" data-ex="${x.id}" data-date="${date}"${ok ? ' checked' : ''} aria-label="Concluir ${esc(x.nome)}">
      <span class="txt"><strong>${esc(x.nome)}</strong>${x.series ? `<br><small>${esc(x.series)}</small>` : ''}</span>
      <label class="kg">
        <input type="number" inputmode="decimal" min="0" step="0.5" data-carga="${x.id}" data-date="${date}" value="${kg != null ? kg : ''}" placeholder="0" aria-label="Carga em kg: ${esc(x.nome)}">
        <span>kg</span>
      </label>
    </li>`;
  }).join('');
  return `<p class="plano-nome">${esc(p.nome || 'Treino')}</p>
    ${barra('Treino do dia', st.done, st.total)}
    <ul>${rows}</ul>`;
}

function grafico(pts) {
  const W = 300, H = 96, p = 14;
  const ks = pts.map(x => x.kg);
  const min = Math.min(...ks), max = Math.max(...ks), span = max - min || 1;
  const X = i => (pts.length === 1 ? W / 2 : p + (i * (W - 2 * p)) / (pts.length - 1));
  const Y = k => (max === min ? H / 2 : H - p - ((k - min) / span) * (H - 2 * p));
  const path = pts.map((x, i) => `${i ? 'L' : 'M'}${X(i).toFixed(1)} ${Y(x.kg).toFixed(1)}`).join(' ');
  const dots = pts.map((x, i) => `<circle cx="${X(i).toFixed(1)}" cy="${Y(x.kg).toFixed(1)}" r="4.5"/>`).join('');
  return `<svg class="graf" viewBox="0 0 ${W} ${H}" role="img" aria-label="Evolução da carga">${pts.length > 1 ? `<path d="${path}"/>` : ''}${dots}</svg>`;
}

function calendario() {
  const { y, m } = calMonth;
  const dias = new Date(y, m + 1, 0).getDate();
  const off = (new Date(y, m, 1).getDay() + 6) % 7;
  const hoje = hojeISO();
  let cells = ['S', 'T', 'Q', 'Q', 'S', 'S', 'D'].map(l => `<span class="cal-h">${l}</span>`).join('');
  for (let i = 0; i < off; i++) cells += '<span class="cal-v"></span>';
  for (let d = 1; d <= dias; d++) {
    const s = iso(new Date(y, m, d));
    const st = statDia(s);
    const p = pct(st.done, st.total);
    const cheio = st.total > 0 && st.done >= st.total;
    cells += `<button type="button" class="cal-d${st.total ? ' tem' : ''}${cheio ? ' cheio' : ''}${s === hoje ? ' hoje' : ''}${s === selDate ? ' sel' : ''}"
      style="--p:${p}" data-act="cal-day" data-date="${s}" aria-label="Dia ${d}, ${st.total ? p + '% do treino' : 'sem treino'}">${d}</button>`;
  }
  const mes = new Date(y, m, 1).toLocaleDateString('pt-BR', { month: 'long', year: 'numeric' });
  return `
    <div class="cal-top">
      <button type="button" class="ghost" data-act="cal-mes" data-n="-1" aria-label="Mês anterior">‹</button>
      <strong>${esc(mes)}</strong>
      <button type="button" class="ghost" data-act="cal-mes" data-n="1" aria-label="Próximo mês">›</button>
    </div>
    <div class="cal">${cells}</div>
    <p class="legenda">Ponto = dia de treino. Quanto mais preenchido, mais exercícios feitos; verde cheio = treino completo. Toque num dia para ver ou ajustar.</p>`;
}

/* ---------- telas ---------- */
function viewHoje() {
  const hoje = new Date();
  const t = iso(hoje);
  const amanha = new Date(hoje.getFullYear(), hoje.getMonth(), hoje.getDate() + 1);
  const its = itemsOf(t);
  const feitos = its.filter(i => i.done).length;
  const prox = db.avals.filter(a => a.date >= t).sort(byDate);
  const p = db.workouts[hoje.getDay()];
  const st = statDia(t);

  const resumo = `
    <div class="resumo">
      <div class="nota amarelo"><b>${feitos}/${its.length}</b><span>tarefas de hoje</span></div>
      <div class="nota rosa"><b>${prox.length ? contagem(prox[0].date) : '—'}</b><span>${prox.length ? esc(matNome(prox[0].materiaId)) : 'sem avaliações'}</span></div>
      <div class="nota lilas"><b>${p && st.total ? pct(st.done, st.total) + '%' : 'Descanso'}</b><span>${p && st.total ? 'treino de hoje' : 'hoje'}</span></div>
    </div>`;

  return resumo + `<div class="grade">
    ${bloco('rosa', '✏️ Hoje', lista(its) + formItem(t))}
    ${bloco('lilas', '💪 Treino de hoje', sessao(t) + barraSemana(t))}
    ${bloco('amarelo', '🎯 Metas', metasResumo())}
    ${bloco('laranja', '📚 Próximas avaliações', prox.length ? `<ul>${prox.slice(0, 3).map(avalRow).join('')}</ul>` : '<p class="vazio">Nenhuma prova ou trabalho marcado.</p>')}
    ${bloco('menta', '🌙 Amanhã', treinoBox(amanha.getDay()) + lista(itemsOf(iso(amanha))))}
    ${bloco('azul', '💾 Seus dados', `
      <p class="vazio">${persistido
        ? 'Tudo é salvo sozinho neste aparelho, e o armazenamento está protegido ✓'
        : 'Tudo é salvo sozinho neste aparelho. Para ficar mais seguro, instale o app na tela inicial do celular.'}</p>
      <div class="acoes">
        <button type="button" class="ghost" data-act="export">Salvar cópia (opcional)</button>
        <label class="ghost">Restaurar cópia<input type="file" accept="application/json" id="import" hidden></label>
      </div>`)}
  </div>`;
}

function viewSemana() {
  const t = hojeISO();
  const fim = new Date(weekStart.getFullYear(), weekStart.getMonth(), weekStart.getDate() + 6);
  let dias = '';

  for (let k = 0; k < 7; k++) {
    const d = new Date(weekStart.getFullYear(), weekStart.getMonth(), weekStart.getDate() + k);
    const s = iso(d);
    const provas = db.avals.filter(a => a.date === s);
    const itens = itemsOf(s);
    const depois = `<small>${esc(fmt(d))}</small>${s === t ? '<em class="hojetag">hoje</em>' : ''}`;
    const corpo = `
      ${treinoBox(d.getDay())}
      ${provas.length ? `<p class="sub">Provas e trabalhos</p><div class="dia"><p>${provas.map(a => `<span class="tag ${a.tipo === 'Prova' ? 'prova' : 'trab'}">${a.tipo === 'Prova' ? '📚' : '📝'} ${esc(a.tipo)}: ${esc(matNome(a.materiaId))}</span>`).join(' ')}</p></div>` : ''}
      <p class="sub">Compromissos e tarefas</p>
      ${itens.length ? `<ul>${itens.map(li).join('')}</ul>` : ''}
      ${formItem(s)}`;
    dias += bloco(CORES[k], DIAS[d.getDay()], corpo, depois);
  }

  return `
    <div class="nav">
      <button type="button" class="ghost" data-act="week" data-n="-1">‹ Anterior</button>
      <button type="button" class="ghost" data-act="week-now">Esta semana</button>
      <button type="button" class="ghost" data-act="week" data-n="1">Próxima ›</button>
    </div>
    <p class="range">${esc(fmt(weekStart))} a ${esc(fmt(fim))}</p>
    <div class="grade">${dias}</div>`;
}

/* ----- Escola ----- */
const TIPOS = ['Prova', 'Trabalho'];
const classeTipo = t => (t === 'Prova' ? 'prova' : 'trab');

// Regra da escola: (1º tri x 1) + (2º tri x 2) + (3º tri x 3) precisa dar pelo menos 36
const PESOS_TRI = [1, 2, 3];
const SOMA_MIN = 36;

function calcMateria(m) {
  const { t1, t2, t3 } = m;
  if (t1 == null || t2 == null) {
    return { cls: '', cel: '<span class="vz">—</span>', msg: 'Preencha o 1º e o 2º trimestre para ver quanto precisa tirar no 3º.' };
  }
  const parcial = t1 * PESOS_TRI[0] + t2 * PESOS_TRI[1];
  if (t3 != null) {
    const total = parcial + t3 * PESOS_TRI[2];
    const ok = total >= SOMA_MIN - 1e-9;
    return {
      cls: ok ? 'ok' : 'no',
      cel: `${ok ? '✅' : '⚠️'} <b>${fmtKg(total)}</b><small>soma (mín. ${SOMA_MIN})</small>`,
      msg: `${ok ? 'Passou de ano' : 'Abaixo do mínimo'}: soma ${fmtKg(total)}, precisa de ${SOMA_MIN}.`
    };
  }
  const need = (SOMA_MIN - parcial) / PESOS_TRI[2];
  const conta = `${fmtKg(t1)}×1 + ${fmtKg(t2)}×2 = ${fmtKg(parcial)}`;
  if (need <= 0) return { cls: 'ok', cel: '✅<small>já passou</small>', msg: `Já passou, mesmo com zero no 3º trimestre (${conta}).` };
  if (need > 10 + 1e-9) {
    const max = parcial + 10 * PESOS_TRI[2];
    return { cls: 'no', cel: `⚠️<small>não dá mais (máx. ${fmtKg(max)})</small>`, msg: `Mesmo com 10 no 3º trimestre a soma seria ${fmtKg(max)}, abaixo de ${SOMA_MIN} (${conta}).` };
  }
  const dec = Math.ceil(need * 10 - 1e-9) / 10;
  const inteira = Math.ceil(need - 1e-9);
  return {
    cls: '',
    cel: `<b>${fmtKg(dec)}</b>${Number.isInteger(dec) ? '' : `<small>inteira: ${inteira}</small>`}`,
    msg: `Precisa de ${fmtKg(dec)} no 3º trimestre (${conta}; faltam ${fmtKg(SOMA_MIN - parcial)} pontos e o 3º vale ×3).`
  };
}

const celCalc = m => {
  const c = calcMateria(m);
  return `<td class="res ${c.cls}" data-calc="${m.id}" title="${esc(c.msg)}">${c.cel}</td>`;
};

function tabelaAvals(list) {
  if (!list.length) return '<p class="vazio">Nada por aqui.</p>';
  return `<div class="tabela"><table>
    <thead><tr><th>Data</th><th>Matéria</th><th>Tipo</th><th>Conteúdo</th><th></th></tr></thead>
    <tbody>${list.map(a => `<tr>
      <td>${esc(fmt(parse(a.date)))}</td>
      <td>${esc(matNome(a.materiaId))}</td>
      <td><span class="tag ${classeTipo(a.tipo)}">${esc(a.tipo)}</span></td>
      <td>${esc(a.conteudo || '—')}</td>
      <td><button type="button" class="x" data-act="del-aval" data-id="${a.id}" aria-label="Apagar">×</button></td>
    </tr>`).join('')}</tbody></table></div>`;
}

function calendarioAgenda() {
  const { y, m } = agMonth;
  const dias = new Date(y, m + 1, 0).getDate();
  const off = (new Date(y, m, 1).getDay() + 6) % 7;
  const hoje = hojeISO();
  let cells = ['S', 'T', 'Q', 'Q', 'S', 'S', 'D'].map(l => `<span class="cal-h">${l}</span>`).join('');
  for (let i = 0; i < off; i++) cells += '<span class="cal-v"></span>';
  for (let d = 1; d <= dias; d++) {
    const s = iso(new Date(y, m, d));
    const as = db.avals.filter(a => a.date === s);
    const pts = as.slice(0, 3).map(a => `<i class="${classeTipo(a.tipo)}"></i>`).join('');
    cells += `<button type="button" class="cal-d${s === hoje ? ' hoje' : ''}${s === selAgenda ? ' sel' : ''}" style="--p:0"
      data-act="ag-day" data-date="${s}" aria-label="Dia ${d}, ${as.length} avaliações">${d}<span class="pts">${pts}</span></button>`;
  }
  const mes = new Date(y, m, 1).toLocaleDateString('pt-BR', { month: 'long', year: 'numeric' });
  return `
    <div class="cal-top">
      <button type="button" class="ghost" data-act="ag-mes" data-n="-1" aria-label="Mês anterior">‹</button>
      <strong>${esc(mes)}</strong>
      <button type="button" class="ghost" data-act="ag-mes" data-n="1" aria-label="Próximo mês">›</button>
    </div>
    <div class="cal">${cells}</div>
    <p class="legenda">Ponto rosa = prova, ponto azul = trabalho. Toque num dia para ver os detalhes.</p>`;
}

function segBoletim() {
  const campo = (m, k, rotulo) => `<td><input type="number" inputmode="decimal" min="0" max="10" step="0.1" data-tri="${k}" data-id="${m.id}" value="${m[k] != null ? m[k] : ''}" placeholder="—" aria-label="${rotulo} de ${esc(m.nome)}"></td>`;
  const linhas = db.materias.map(m => `<tr>
      <td class="mat">${esc(m.nome)}</td>
      ${campo(m, 't1', '1º trimestre')}${campo(m, 't2', '2º trimestre')}${campo(m, 't3', '3º trimestre')}
      ${celCalc(m)}
      <td><button type="button" class="x" data-act="del-materia" data-id="${m.id}" aria-label="Excluir ${esc(m.nome)}">×</button></td>
    </tr>`).join('');
  const tabela = db.materias.length
    ? `<div class="tabela"><table class="boletim">
        <colgroup><col><col class="c-tri"><col class="c-tri"><col class="c-tri"><col class="c-res"><col class="c-x"></colgroup>
        <thead><tr><th>Matéria</th><th>1º tri</th><th>2º tri</th><th>3º tri</th><th>Precisa no 3º</th><th></th></tr></thead>
        <tbody>${linhas}</tbody></table></div>`
    : '<p class="vazio">Nenhuma matéria ainda. Adicione a primeira abaixo.</p>';
  return `<div class="grade">${bloco('lilas', '📋 Boletim', `
    ${tabela}
    <p class="legenda">Passa de ano quando 1º tri ×1 + 2º tri ×2 + 3º tri ×3 der ${SOMA_MIN} ou mais. Preencha o 1º e o 2º tri e a coluna da direita mostra a nota mínima do 3º. Verde = já passou, rosa = não dá mais para chegar a ${SOMA_MIN}.</p>
    <form class="add" data-form="materia">
      <input name="nome" placeholder="Nova matéria" aria-label="Nome da matéria" required>
      <button class="primary">Adicionar matéria</button>
    </form>`)}</div>`;
}

function segAgenda() {
  const hoje = hojeISO();
  const doDia = db.avals.filter(a => a.date === selAgenda).sort(byDate);
  const prox = db.avals.filter(a => a.date >= hoje).sort(byDate);
  const passadas = db.avals.filter(a => a.date < hoje).sort(byDate).reverse();
  const form = db.materias.length
    ? `<form class="add" data-form="aval">
        <select name="materia" aria-label="Matéria" required>${db.materias.map(m => `<option value="${m.id}">${esc(m.nome)}</option>`).join('')}</select>
        <select name="tipo" aria-label="Prova ou trabalho">${TIPOS.map(t => `<option>${t}</option>`).join('')}</select>
        <input name="date" type="date" required value="${selAgenda}" aria-label="Data">
        <input name="conteudo" placeholder="Conteúdo" aria-label="Conteúdo">
        <button class="primary">Salvar</button>
      </form>`
    : '<p class="vazio">Primeiro cadastre as matérias na aba Boletim.</p>';
  const sd = parse(selAgenda);
  return `<div class="grade">
    ${bloco('laranja', '📝 Nova prova ou trabalho', form)}
    ${bloco('menta', '🗓️ Agenda do mês', calendarioAgenda())}
    ${bloco('rosa', `📌 ${DIAS[sd.getDay()]}`, tabelaAvals(doDia), `<small>${esc(fmt(sd))}</small>`)}
    ${bloco('lilas', '📚 Próximas', tabelaAvals(prox))}
    ${passadas.length ? bloco('azul', '✔️ Já passaram', tabelaAvals(passadas)) : ''}
  </div>`;
}

function viewEscola() {
  const seg = `<div class="seg">${[['boletim', 'Boletim'], ['agenda', 'Agenda']]
    .map(([k, t]) => `<button type="button" data-act="esc-seg" data-seg="${k}" class="${escolaSeg === k ? 'on' : ''}">${t}</button>`).join('')}</div>`;
  return seg + (escolaSeg === 'boletim' ? segBoletim() : segAgenda());
}

/* ----- Metas (o progresso vem dos checks da aba Treino) ----- */
function exDoPlano() {
  const l = [];
  ORDEM.forEach(n => { const w = db.workouts[n]; if (w) w.exs.forEach(x => l.push({ id: x.id, nome: x.nome, dia: DIAS[n] })); });
  return l;
}

function cargaAtual(id) {
  const datas = Object.keys(db.sessions).sort().reverse();
  for (const d of datas) {
    const s = db.sessions[d];
    if (s.done.includes(id) && s.cargas[id] != null) return s.cargas[id];
  }
  return null;
}

function treinosCompletos(desde) {
  let n = 0;
  const fim = hojeISO();
  for (let d = parse(desde); iso(d) <= fim; d.setDate(d.getDate() + 1)) {
    const st = statDia(iso(d));
    if (st.total && st.done >= st.total) n++;
  }
  return n;
}

function semanasBatidas(m) {
  let n = 0;
  const fim = mondayOf(new Date());
  for (let d = mondayOf(parse(m.desde)); d <= fim; d = new Date(d.getFullYear(), d.getMonth(), d.getDate() + 7)) {
    if (statSemana(iso(d)).completos >= m.alvo) n++;
  }
  return n;
}

function prazoTxt(prazo) {
  return diasAte(prazo) < 0 ? `Prazo encerrado em ${fmt(parse(prazo))}` : `Prazo: ${fmt(parse(prazo))} (${contagem(prazo)})`;
}

function progressoMeta(m) {
  if (m.tipo === 'semana') {
    const c = statSemana(hojeISO()).completos;
    return { p: pct(Math.min(c, m.alvo), m.alvo), direita: `${c}/${m.alvo} nesta semana`, extra: `Semanas batidas: ${semanasBatidas(m)}` };
  }
  if (m.tipo === 'total') {
    const c = treinosCompletos(m.desde);
    return { p: pct(Math.min(c, m.alvo), m.alvo), direita: `${c}/${m.alvo} treinos`, extra: m.prazo ? prazoTxt(m.prazo) : '' };
  }
  const at = cargaAtual(m.exId);
  const base = m.base || 0;
  const atual = at != null ? at : base;
  const p = Math.max(0, Math.min(100, Math.round(((atual - base) / (m.alvo - base)) * 100)));
  return { p, direita: `${fmtKg(atual)}/${fmtKg(m.alvo)} kg`, extra: m.prazo ? prazoTxt(m.prazo) : '' };
}

function metasResumo() {
  if (!db.metas.length) return '<p class="vazio">Crie metas na aba Metas e acompanhe o progresso aqui.</p>';
  const lista = db.metas.map(m => ({ m, pr: progressoMeta(m) })).sort((a, b) => (a.pr.p >= 100) - (b.pr.p >= 100));
  return lista.slice(0, 3).map(({ m, pr }) => barraP(esc(m.nome), pr.direita, pr.p)).join('');
}

function cartaoMeta(m, k) {
  const pr = progressoMeta(m);
  const ok = pr.p >= 100;
  return bloco(ok ? 'menta' : CORES[k % CORES.length], `${ok ? '🎉' : '🎯'} ${esc(m.nome)}`, `
    ${barraP(ok ? 'Meta batida!' : 'Progresso', pr.direita, pr.p)}
    ${pr.extra ? `<p class="vazio">${pr.extra}</p>` : ''}
    <div class="acoes"><button type="button" class="ghost perigo" data-act="del-meta" data-id="${m.id}">🗑 Remover</button></div>`);
}

function viewMetas() {
  const md = metaDraft;
  const ex = exDoPlano();
  const campoEx = md.tipo === 'carga'
    ? (ex.length
      ? `<select name="ex" data-meta="ex" aria-label="Exercício" required>${ex.map(x => `<option value="${x.id}"${md.ex === x.id ? ' selected' : ''}>${esc(x.nome)} (${esc(x.dia)})</option>`).join('')}</select>`
      : '<p class="vazio">Cadastre os treinos na aba Treino, em Plano, para criar metas de carga.</p>')
    : '';
  const rotulo = md.tipo === 'semana' ? 'Treinos por semana' : md.tipo === 'total' ? 'Total de treinos' : 'Carga alvo (kg)';
  const opt = (v, t) => `<option value="${v}"${md.tipo === v ? ' selected' : ''}>${t}</option>`;
  const form = `
    <form class="add" data-form="meta">
      <select name="tipo" data-meta="tipo" aria-label="Tipo de meta">
        ${opt('semana', 'Treinos por semana')}${opt('total', 'Total de treinos completos')}${opt('carga', 'Carga em um exercício')}
      </select>
      ${campoEx}
      <input name="alvo" type="number" inputmode="decimal" min="1" step="${md.tipo === 'carga' ? '0.5' : '1'}" required data-meta="alvo" value="${esc(md.alvo)}" placeholder="${rotulo}" aria-label="${rotulo}">
      ${md.tipo !== 'semana' ? `<input name="prazo" type="date" data-meta="prazo" value="${esc(md.prazo)}" aria-label="Prazo (opcional)">` : ''}
      <button class="primary">Criar meta</button>
    </form>
    <p class="vazio">O progresso avança sozinho conforme ela marca os exercícios na aba Treino. Treino completo = todos os exercícios do dia marcados.</p>`;
  const ordenadas = db.metas.map(m => ({ m, ok: progressoMeta(m).p >= 100 })).sort((a, b) => a.ok - b.ok).map(x => x.m);
  return `<div class="grade">
    ${bloco('azul', '➕ Nova meta', form)}
    ${ordenadas.map(cartaoMeta).join('')}
  </div>${db.metas.length ? '' : '<p class="intro">Nenhuma meta ainda. Crie a primeira acima.</p>'}`;
}

/* ----- Treino: Progresso / Evolução / Plano ----- */
function segProgresso() {
  const sd = parse(selDate);
  return `<div class="grade">
    ${bloco('menta', '🗓️ Calendário', calendario())}
    ${bloco('lilas', `💪 ${DIAS[sd.getDay()]}`, sessao(selDate), `<small>${esc(fmt(sd))}</small>`)}
    ${bloco('rosa', '📈 Semana', barraSemana(selDate))}
  </div>`;
}

function segEvolucao() {
  const mapa = {};
  Object.keys(db.sessions).sort().forEach(d => {
    const s = db.sessions[d];
    s.done.forEach(id => { if (s.cargas[id] != null) (mapa[id] = mapa[id] || []).push({ d, kg: s.cargas[id] }); });
  });
  const diaDe = id => ORDEM.findIndex(n => db.workouts[n] && db.workouts[n].exs.some(x => x.id === id));
  const ids = Object.keys(mapa).sort((a, b) => {
    const da = diaDe(a), dbb = diaDe(b);
    return (da < 0 ? 99 : da) - (dbb < 0 ? 99 : dbb);
  });

  if (!ids.length) {
    return `<div class="grade">${bloco('lilas', '📈 Evolução de carga',
      '<p class="vazio">Quando ela marcar um exercício como feito com a carga em kg, a evolução aparece aqui, com gráfico.</p>')}</div>`;
  }

  return `<div class="grade">${ids.map((id, k) => {
    const pts = mapa[id];
    const ini = pts[0], fim = pts[pts.length - 1];
    const diff = fim.kg - ini.kg;
    const idx = diaDe(id);
    const onde = idx >= 0 ? DIAS[ORDEM[idx]] : '';
    const sinal = diff > 0 ? '+' : '';
    return bloco(CORES[k % CORES.length], esc(db.exNomes[id] || 'Exercício'), `
      ${onde ? `<p class="vazio">${onde}</p>` : ''}
      <div class="evo-stats">
        <span>Início <b>${fmtKg(ini.kg)} kg</b></span>
        <span>Atual <b>${fmtKg(fim.kg)} kg</b></span>
        <span class="${diff > 0 ? 'up' : ''}">Variação <b>${sinal}${fmtKg(diff)} kg</b></span>
      </div>
      ${grafico(pts)}
      <p class="evo-datas">${esc(fmt(parse(ini.d)))} a ${esc(fmt(parse(fim.d)))}, ${pts.length} ${pts.length === 1 ? 'registro' : 'registros'}</p>`);
  }).join('')}</div>`;
}

function blocoPlano(n, cor) {
  const w = db.workouts[n];
  let corpo;
  if (editingDay === n && draft) {
    corpo = `
      <form class="tform" data-form="treino" data-day="${n}">
        <input data-draft="nome" placeholder="Nome do treino (ex.: Peito e tríceps)" value="${esc(draft.nome)}" aria-label="Nome do treino">
        ${draft.exs.map((x, i) => `
          <div class="exrow">
            <input data-draft="ex-nome" data-i="${i}" placeholder="Exercício" value="${esc(x.nome)}" aria-label="Exercício ${i + 1}">
            <input data-draft="ex-series" data-i="${i}" placeholder="3x12" value="${esc(x.series)}" aria-label="Séries e repetições ${i + 1}">
            <button type="button" class="x" data-act="ex-rm" data-i="${i}" aria-label="Remover exercício ${i + 1}">×</button>
          </div>`).join('')}
        <button type="button" class="ghost" data-act="ex-add">+ Exercício</button>
        <div class="acoes">
          <button class="primary">Salvar</button>
          <button type="button" class="ghost" data-act="treino-cancel">Cancelar</button>
        </div>
      </form>`;
  } else if (w) {
    corpo = `${treinoBox(n)}
      <div class="acoes">
        <button type="button" class="ghost" data-act="treino-edit" data-day="${n}">✎ Editar</button>
        <button type="button" class="ghost perigo" data-act="treino-del" data-day="${n}">🗑 Excluir</button>
      </div>`;
  } else {
    corpo = `<p class="vazio">Sem treino neste dia.</p>
      <div class="acoes"><button type="button" class="primary" data-act="treino-edit" data-day="${n}">+ Adicionar treino</button></div>`;
  }
  return bloco(cor, DIAS[n], corpo);
}

function segPlano() {
  return `<p class="intro">Monte o treino de cada dia uma vez só. Ele aparece sozinho em Hoje e na Semana, e a carga de cada exercício você anota ao treinar.</p>
    <div class="grade">${ORDEM.map((n, k) => blocoPlano(n, CORES[k])).join('')}</div>`;
}

function viewTreino() {
  const seg = `<div class="seg">${[['progresso', 'Progresso'], ['evolucao', 'Evolução'], ['plano', 'Plano']]
    .map(([k, t]) => `<button type="button" data-act="seg" data-seg="${k}" class="${treinoSeg === k ? 'on' : ''}">${t}</button>`).join('')}</div>`;
  return seg + (treinoSeg === 'progresso' ? segProgresso() : treinoSeg === 'evolucao' ? segEvolucao() : segPlano());
}

const VIEWS = { hoje: viewHoje, semana: viewSemana, escola: viewEscola, treino: viewTreino, metas: viewMetas };

/* ---------- render ---------- */
function render() {
  const agora = new Date();
  const h = agora.getHours();
  document.getElementById('saudacao').textContent = h < 12 ? 'Bom dia' : h < 18 ? 'Boa tarde' : 'Boa noite';
  document.getElementById('data').textContent =
    agora.toLocaleDateString('pt-BR', { weekday: 'long', day: 'numeric', month: 'long' });
  document.getElementById('app').innerHTML = VIEWS[view]();
  document.querySelectorAll('#tabs button').forEach(b => {
    const on = b.dataset.view === view;
    b.classList.toggle('on', on);
    if (on) b.setAttribute('aria-current', 'page'); else b.removeAttribute('aria-current');
  });
  if (pendingFocus) {
    const campo = document.querySelector(pendingFocus);
    if (campo) campo.focus();
    pendingFocus = null;
  }
}

/* ---------- eventos ---------- */
function exportar() {
  const a = document.createElement('a');
  a.href = URL.createObjectURL(new Blob([JSON.stringify(db, null, 2)], { type: 'application/json' }));
  a.download = `organizador-${hojeISO()}.json`;
  a.click();
  setTimeout(() => URL.revokeObjectURL(a.href), 1000);
}

const exVazio = () => ({ id: uid(), nome: '', series: '' });

document.getElementById('tabs').addEventListener('click', e => {
  const b = e.target.closest('button[data-view]');
  if (!b) return;
  view = b.dataset.view;
  editingDay = null;
  draft = null;
  if (view === 'treino') {
    selDate = hojeISO();
    calMonth = { y: new Date().getFullYear(), m: new Date().getMonth() };
  }
  render();
  window.scrollTo(0, 0);
});

document.getElementById('app').addEventListener('click', e => {
  const el = e.target.closest('[data-act]');
  if (!el) return;
  const { act, id, day } = el.dataset;

  if (act === 'export') { exportar(); return; }

  if (act === 'toggle') {
    const it = db.items.find(i => i.id === id);
    if (it) it.done = !it.done;
  } else if (act === 'del-item') {
    db.items = db.items.filter(i => i.id !== id);
  } else if (act === 'del-aval') {
    if (!confirm('Apagar esta prova ou trabalho?')) return;
    db.avals = db.avals.filter(x => x.id !== id);
  } else if (act === 'del-materia') {
    if (!confirm('Excluir esta matéria e todas as provas e trabalhos dela?')) return;
    db.materias = db.materias.filter(x => x.id !== id);
    db.avals = db.avals.filter(x => x.materiaId !== id);
  } else if (act === 'del-meta') {
    db.metas = db.metas.filter(x => x.id !== id);
  } else if (act === 'esc-seg') {
    escolaSeg = el.dataset.seg;
    render();
    return;
  } else if (act === 'ag-mes') {
    const d = new Date(agMonth.y, agMonth.m + Number(el.dataset.n), 1);
    agMonth = { y: d.getFullYear(), m: d.getMonth() };
    render();
    return;
  } else if (act === 'ag-day') {
    selAgenda = el.dataset.date;
    render();
    return;
  } else if (act === 'week') {
    weekStart = new Date(weekStart.getFullYear(), weekStart.getMonth(), weekStart.getDate() + Number(el.dataset.n) * 7);
    render();
    return;
  } else if (act === 'week-now') {
    weekStart = mondayOf(new Date());
    render();
    return;
  } else if (act === 'seg') {
    treinoSeg = el.dataset.seg;
    editingDay = null;
    draft = null;
    render();
    return;
  } else if (act === 'cal-mes') {
    const d = new Date(calMonth.y, calMonth.m + Number(el.dataset.n), 1);
    calMonth = { y: d.getFullYear(), m: d.getMonth() };
    render();
    return;
  } else if (act === 'cal-day') {
    selDate = el.dataset.date;
    render();
    return;
  } else if (act === 'ex-toggle') {
    const exId = el.dataset.ex, date = el.dataset.date;
    const s = getSessao(date);
    const i = s.done.indexOf(exId);
    if (i >= 0) {
      s.done.splice(i, 1);
    } else {
      s.done.push(exId);
      const campo = document.querySelector(`input[data-carga="${exId}"][data-date="${date}"]`);
      const kg = lerKg(campo && campo.value);
      if (kg != null) s.cargas[exId] = kg;
    }
    s.total = planTotal(date);
  } else if (act === 'treino-edit') {
    const n = Number(day);
    const w = db.workouts[n];
    draft = w ? { nome: w.nome, exs: w.exs.map(x => ({ ...x })) } : { nome: '', exs: [exVazio()] };
    if (!draft.exs.length) draft.exs.push(exVazio());
    editingDay = n;
    pendingFocus = 'input[data-draft="nome"]';
    render();
    return;
  } else if (act === 'ex-add') {
    draft.exs.push(exVazio());
    pendingFocus = `input[data-draft="ex-nome"][data-i="${draft.exs.length - 1}"]`;
    render();
    return;
  } else if (act === 'ex-rm') {
    draft.exs.splice(Number(el.dataset.i), 1);
    if (!draft.exs.length) draft.exs.push(exVazio());
    render();
    return;
  } else if (act === 'treino-cancel') {
    editingDay = null;
    draft = null;
    render();
    return;
  } else if (act === 'treino-del') {
    delete db.workouts[day]; // sem popup, apaga na hora (o histórico de cargas fica)
    editingDay = null;
    draft = null;
  } else {
    return;
  }
  save();
  render();
});

// Guarda o que ela digita no treino em edição (sem redesenhar a tela)
document.getElementById('app').addEventListener('input', e => {
  const t = e.target;
  if (t.dataset && t.dataset.meta) { metaDraft[t.dataset.meta] = t.value; return; }
  if (t.dataset && t.dataset.tri) {
    const m = db.materias.find(x => x.id === t.dataset.id);
    const box = document.querySelector(`[data-calc="${t.dataset.id}"]`);
    if (!m || !box) return;
    m[t.dataset.tri] = lerNota(t.value);
    save();
    box.outerHTML = celCalc(m);
    return;
  }
  const k = t.dataset && t.dataset.draft;
  if (!k || !draft) return;
  if (k === 'nome') { draft.nome = t.value; return; }
  const ex = draft.exs[Number(t.dataset.i)];
  if (ex) ex[k === 'ex-nome' ? 'nome' : 'series'] = t.value;
});

document.getElementById('app').addEventListener('submit', e => {
  const f = e.target.closest('form[data-form]');
  if (!f) return;
  e.preventDefault();
  const d = new FormData(f);

  if (f.dataset.form === 'item') {
    const title = (d.get('title') || '').trim();
    if (!title) return;
    db.items.push({ id: uid(), title, date: f.dataset.date, time: d.get('time') || '', done: false });
  } else if (f.dataset.form === 'aval') {
    const materiaId = d.get('materia');
    const date = d.get('date');
    if (!materiaId || !date) return;
    db.avals.push({ id: uid(), materiaId, tipo: TIPOS.includes(d.get('tipo')) ? d.get('tipo') : 'Prova', date,
      conteudo: (d.get('conteudo') || '').trim() });
    selAgenda = date;
    agMonth = { y: parse(date).getFullYear(), m: parse(date).getMonth() };
  } else if (f.dataset.form === 'materia') {
    const nome = (d.get('nome') || '').trim();
    if (!nome) return;
    if (!db.materias.some(m => m.nome.toLowerCase() === nome.toLowerCase())) db.materias.push({ id: uid(), nome, t1: null, t2: null, t3: null });
  } else if (f.dataset.form === 'meta') {
    const tipo = d.get('tipo');
    const alvo = lerKg(d.get('alvo'));
    if (!['semana', 'total', 'carga'].includes(tipo) || !(alvo > 0)) return;
    const m = { id: uid(), tipo, alvo, desde: hojeISO(), prazo: d.get('prazo') || '' };
    if (tipo === 'semana') {
      m.alvo = Math.min(7, Math.round(alvo));
      m.prazo = '';
      m.nome = `${m.alvo} treinos por semana`;
    } else if (tipo === 'total') {
      m.alvo = Math.round(alvo);
      m.nome = `${m.alvo} treinos completos`;
    } else {
      const x = exDoPlano().find(e => e.id === d.get('ex'));
      if (!x) return;
      const base = cargaAtual(x.id) || 0;
      if (alvo <= base) { alert(`A carga alvo precisa ser maior que a atual (${fmtKg(base)} kg).`); return; }
      m.exId = x.id; m.base = base; m.nome = `${x.nome} ${fmtKg(alvo)} kg`;
    }
    if (m.alvo < 1) return;
    db.metas.push(m);
    metaDraft = { tipo, alvo: '', ex: '', prazo: '' };
  } else if (f.dataset.form === 'treino') {
    if (!draft) return;
    const nome = draft.nome.trim();
    const exs = draft.exs.map(x => ({ id: x.id, nome: x.nome.trim(), series: x.series.trim() })).filter(x => x.nome);
    if (!nome && !exs.length) delete db.workouts[f.dataset.day];
    else db.workouts[f.dataset.day] = { nome, exs };
    exs.forEach(x => { db.exNomes[x.id] = x.nome; });
    editingDay = null;
    draft = null;
  }
  save();
  render();
});

document.getElementById('app').addEventListener('change', e => {
  const t = e.target;

  if (t.dataset && t.dataset.meta === 'tipo') { metaDraft.tipo = t.value; render(); return; }

  // Carga (kg) de um exercício: salva ao sair do campo
  if (t.dataset && t.dataset.carga) {
    const s = getSessao(t.dataset.date);
    const kg = lerKg(t.value);
    if (kg == null) delete s.cargas[t.dataset.carga]; else s.cargas[t.dataset.carga] = kg;
    s.total = planTotal(t.dataset.date);
    save();
    return;
  }

  if (t.id !== 'import') return;
  const file = t.files[0];
  if (!file) return;
  if (!confirm('Restaurar substitui os dados atuais. Continuar?')) { t.value = ''; return; }
  file.text().then(txt => {
    try {
      const d = JSON.parse(txt);
      if (!Array.isArray(d.items)) throw new Error('formato');
      db = carregar(d);
      save();
      render();
      alert('Cópia restaurada.');
    } catch (err) {
      alert('Arquivo inválido. Use uma cópia salva por este site.');
    }
  });
});

// Atualiza a data ao voltar para a aba (virou o dia, por exemplo)
document.addEventListener('visibilitychange', () => { if (!document.hidden) render(); });

if ('serviceWorker' in navigator && location.protocol !== 'file:') {
  navigator.serviceWorker.register('sw.js').catch(() => {});
}

render();
protegerDados();
